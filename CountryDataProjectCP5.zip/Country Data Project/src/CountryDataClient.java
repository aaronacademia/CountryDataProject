import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

//Aaron Academia
//Client for the Country data project.  It will read from a file
//and analyze the data
//December 9, 2022
public class CountryDataClient {

	public static void main(String[] args) throws FileNotFoundException{
		File inputFile =new File("CountryDataSet.csv");
		Scanner input = new Scanner(inputFile);
		ArrayList<Country> countries = new ArrayList<>();
		int countryCounter = 0;
		String line = input.nextLine();
		String[] splitLine = line.split(",");
		String series = splitLine[0];
		line = input.nextLine();
		splitLine = line.split(",");
		int count = splitLine.length-1;
		ArrayList<Integer> years = new ArrayList<>();
		for (int i=0;i<count;i++) {
			years.add(i, Integer.parseInt(splitLine[i+1]));
		}

		while (input.hasNextLine()) {
			line = input.nextLine();
			splitLine = line.split(",");
			String countryName = splitLine[0];
			ArrayList<Double> values = new ArrayList<>();
			for (int i=0;i<count;i++)
				values.add(i, Double.parseDouble(splitLine[i+1]));
			Country myCountry = new Country(countryName, series, years, values);
			countries.add(countryCounter, myCountry);
			countryCounter++;
			//countries[countryCounter]= myCountry;
		//	countryCounter++;
			
		} //end of while
		for(Country myCountry: countries) {
			System.out.println(myCountry);
		}
		input.close();//last line in the main method 
	}
	
	public static void removeByName(ArrayList<Country> countries, String name) {
		for (int i = 0; i < countries.size(); i++)
			if (countries.get(i).getCountry().equals(name))
				countries.remove(i);
	}
	
	public static void removeNoTrend(ArrayList<Country> countries) {
		for (int i = 0; i < countries.size(); i++)
			if (countries.get(i).getTrend().equals("no trend")) {
				countries.remove(i);
				i--;
			}
	}
	
	public static ArrayList<String> getListBasedOnTrend(ArrayList<Country> countries, String trendType) {
		if (!trendType.equals("up") && !trendType.equals("down") && !trendType.equals("no trend")) throw new IllegalArgumentException("not a trend type");
		ArrayList<String> newList = new ArrayList<>();
		for (Country country : countries)
			if (country.getTrend().equals(trendType))
				newList.add(country.getCountry());
		return newList;
	}
	
	

}
