import java.util.ArrayList;

/*Aaron Academia
 * December 9, 2022
 * Country class will contain all of the info about a country:
 * it's name, series name, years and data for the series
 * It will also be able to calculate and return information about the 
 * country */
public class Country {

	private String name;
	private String series;
	private ArrayList<Integer> years;
	private ArrayList<Double> values;
	
	//Constructor
	public Country(String name, String series, ArrayList<Integer> years, ArrayList<Double> values) {
		this.name = name;
		this.series = series;
		this.years = years;
		this.values = values;
	}
	
//prints all the pertinent information about a country, nicely formatted
	public String toString() {
		String output="";
		for (int i=0; i < years.size();i++) {
			output +=years.get(i)+"\t";
		}
		output +="\n";
		for (int i=0; i < values.size();i++) {
			double value =Math.round(values.get(i)*100.0)/100.0;
			output +=value+"\t";
		}
		output +="\nThis is the \""+series+"\" for "+name+"\n";
		output +="Minimum: "+min()+"\n"+"Maximum: "+max();
		output +="\nTrending: "+getTrend()+"\n";
		return output;
	}
	
	//Calculate and returns the smallest data value
	public double min() {
		double min = values.get(0);
		for (int i=1; i<values.size();i++) {
			double data = values.get(i);
			if (data< min) 
				min = data;
		}
		return min;

	}
	
	//Calculate and returns the largest data value
	public double max() {
		double max = values.get(0);
		for (int i=1; i<values.size();i++) {
			double data = values.get(i);
			if (data> max) 
				max = data;
		}
		return max;
	}
	
	//	This method returns the units for the stored data.  
	//  The string that is returned should not include parentheses.  
	//  In the example above, a call to getUnits would return:  % of 
	//  population.
	public String getUnits() {
		String units = "";
		if (this.series.contains(")")) {
			String[] paren = this.series.split("\\(");
			units += paren[1].substring(0, paren[1].length()-1);
		}
		return units;
	}

	//	This method returns an acronym made of the first letter in each of the words in the series name, but excludes: of, in, the, at, to, by, per, on, a, an.  The acronym should be in ALL CAPS and should not include the units.  In the example above, a call to getAcronym would shorten the data series name Access to electricity to simply return: AE.  (If you�re using something like GDP that is already an acronym, it might help for testing to 
	//  adjust your data file to read �Gross domestic product�.)  
	public String getAcronym() {
		String acronym = "";
		String[] noUnits = this.series.split("\\(");
		String[] words = noUnits[0].split(" ");
		for (int i = 0; i<words.length; i++) {
			if (!words[i].equals("of") && !words[i].equals("in") && !words[i].equals("the") && !words[i].equals("at") && !words[i].equals("to") && !words[i].equals("by") && !words[i].equals("per") && !words[i].equals("on") && !words[i].equals("a") && !words[i].equals("an"))
				acronym += words[i].substring(0,1).toUpperCase();
		}
		return acronym;
	}

	//This method returns  �up�, �down�, or �no trend� depending on 
	//which direction the data is trending.  This method must call 
	//the private methods trendsUp and trendsDown.	
	public String getTrend() {
		if (trendsUp(this.values))
			return ("up");
		if (trendsDown(this.values))
			return "down";
		else
			return "no trend";
	}

	//	This method returns a boolean representing whether each 
	//  data point is higher than the previous one.  For example, 
	//  the method would return true if the data values were:  
	//  20, 22, 25, 27, 33.  The method would return false if the
	//  data values were:  20, 22, 22, 22, 25, 33.  (Yes, this is 
	//  a gross simplification of something that would be better 
	//  done with regression, but I don�t think anyone is up for 
	//  programming that right now.  Wait� are you?)   ;)
	private boolean trendsUp(ArrayList<Double> data) {
		boolean trend = true;
		for (int i = 0; i<data.size()-1; i++) {
				if (data.get(i+1)<=data.get(i))
					trend = false;
		}
		return trend;
	}

/* 	Same idea as trendsUp� each data point must be lower than the 
 * one that came before, otherwise it will return false.
 */
	private boolean trendsDown(ArrayList<Double> data) {
		boolean trend = true;
		for (int i = 0; i<data.size()-1; i++) {
				if (data.get(i+1)>=data.get(i))
					trend = false;
		}
		return trend;
	}
	
	//This method will accept a year and a new data point. 
	//These new data points will always be added to the end 
	//of the ArrayLists representing years and data.  This 
	//change should not affect any other country’s information.
	public void addDataPoint(int year, double newDatum) {
		this.years.add(year);
		this.values.add(newDatum);
	}
	
	//This method will accept a year and a new data point.  
	//The data value associated with the given year should 
	//be changed to the given value.  You may assume that the
	//given year is a valid year that already exists in the data for that country.  
	public void editDataPoint(int year, double newDatum) {
		for (int i = 0; i < years.size(); i++) {
			if (years.get(i).equals(year))
				values.add(i, newDatum);
		}
	}

	public String getCountry() {
		return name;
	}
	public String getSeries() {
		String newSeries = this.series;
		if (newSeries.contains(")")) {
			String[] noParen = series.split("\\(");
			newSeries = noParen[0];
		}
		return newSeries;
	}
	public ArrayList<Integer> getYears() {
		return years;
	}
	public ArrayList<Double> getData() {
		return values;
	}
	public void setSeries(String s) {
		series = s;
	}
	public void setData(ArrayList<Double> newData) {
		values = newData;
	}
}